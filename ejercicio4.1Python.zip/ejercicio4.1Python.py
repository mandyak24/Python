pregunta=int(input("Que edad tienes?"))

if pregunta <18:
    print("El usuario es menor de edad")
else: 
    print("El usuario es mayor de edad")